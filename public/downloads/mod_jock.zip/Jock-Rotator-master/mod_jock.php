<?php
/**
 * File mod_jock.php
 *
 * This file builds the Jock Rotator. The Jock Rotator is nothing more than a PHP switch satement.
 * It reads your server's time/date and asks: "Is it before 10:00am? Yes? Then display this jock."
 *
 * @version      3.0.2
 * @author       Greg Rickaby <greg@gregrickaby.com>
 * @copyright    Copyright (c) 2013
 * @license      http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @link         http://gregrickaby.com/jock-rotator-for-joomla
 * @alter        2013.07.04
 *
 */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );


/**
 * Force Time Zone
 *
 * This forces Jock Rotator to ignore the server Time Zone (which is usually GMT) and allows you to specify your own. 
 * To find your timezone visit: http://unicode.org/cldr/data/diff/supplemental/territory_containment_un_m_49.html
 *
 * @author Greg Rickaby
 * @since 1.4
 * @requires PHP 5.1+
 */
date_default_timezone_set( 'America/Chicago' );


/**
 * Jock Rotator Function
 *
 * This executes the jock rotator.You can place this function anywhere in your template and
 * the Jock Rotator will appear.
 *
 * @author Greg Rickaby
 * @since 3.1
 */
jock_rotator();


/**
 * Time switching
 *
 * TO CUSTOMIZE: edit the HTML in each respective time-slot below.
 *
 * @author Greg Rickaby
 * @since 1.0
 */
function jock_rotator() {
	
$i = date( 'w' );
$x = date( 'Hi' );

switch ( $i ) {

################################### Monday - Friday ###################################

case "1":
case "2":
case "3":
case "4":
case "5":

//------------------------------- Weekday Overnights 12a-6a ---------------------------
if ( $x < 600 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//------------------------------- Weekday Mornings 6a-10a -----------------------------
elseif ( $x < 1000 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//------------------------------ Weekday Middays 10a-3p ------------------------------
elseif ( $x < 1500 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }

//------------------------------- Weekday Afternoons 3p-7p ----------------------------
elseif ( $x < 1900 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//------------------------------- Weekday Nights 7p-11:59p ----------------------------
elseif ( $x < 2359 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }

break;

####################################### Saturday ######################################

case "6":  

//------------------------------ Saturday Overnights 12a-6a ---------------------------
if ( $x < 600 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//----------------------------- Saturday Mornings 6a-10a ------------------------------
elseif ( $x < 1000 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//------------------------------- Saturday Middays 10a-3p ----------------------------- 
elseif ( $x < 1500 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//-------------------------------- Saturday Afternoons 3p-7p --------------------------
elseif ( $x < 1900 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//-------------------------------- Saturday Nights 7p-11:59p---------------------------
elseif ( $x < 2359 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }

break;

########################################## Sunday ######################################

case "0":

//------------------------- Sunday Overnights 12a-6a-------------------------------------
if ( $x < 600 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//-------------------------- Sunday Mornings 6a-10a---------------------------------------
elseif ( $x < 1000 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//-------------------------- Sunday Middays 10a-3p ---------------------------------------- 
elseif ( $x < 1500 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//------------------------- Sunday Afternoons 3p-7p ---------------------------------------
elseif ( $x < 1900 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }
//-------------------------- Sunday Nights 7p-11:59p ----------------------------------------
elseif ( $x < 2359 ) { echo '

	<a href="jock-page.html">Jock Name<br /><img src="/images/jock_pics/jock.jpg"></a>

'; }

 // end switch
 } 

// end jock_rotator()
}
?>
