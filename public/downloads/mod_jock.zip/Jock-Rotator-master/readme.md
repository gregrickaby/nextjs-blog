##Instructions##

1. Download https://github.com/gregrickaby/Jock-Rotator/archive/master.zip
2. Rename master.zip to mod_jock.zip
4. Open mod_jock.zip and edit mod_jock.php with any text or code editor
5. Edit the HTML according to the time your jocks are on the air
6. Save 
7. Upload using Joomla!'s Extension Manager

##Requirements##
- Joomla 1.5+
- PHP 5.1+

##Support##

https://github.com/gregrickaby/Jock-Rotator/issues

##Contribute##

https://github.com/gregrickaby/Jock-Rotator

##Change Log##

Version 3.0.2 - July 4, 2013
- Misc. code refactoring

Version 3.0.1 - May 24, 2013
- Added jock_rotator() function

Version 3.0.0 - October 15, 2012
- Added Joomla 3.0 native compatibly

Version 2.5.0 - February 21, 2012
- Added Joomla 2.5 native compatibly
- Cleaned up code and comments

Version 1.7.1 - November 16th, 2011
- Added option to disable caching
- Added Module CSS Suffix
- Added ability to use minutes

Version 1.7 - August 30th, 2011
- Added Joomla 1.7 native compatibly

Version 1.6 - March 6th, 2010
- Added Joomla 1.6 native compatibly

Version 1.5 - February 8th, 2010
- Removed CSS
- Added Joomla 1.5 native compatibly
- Cleaned up code

Version 1.4 - January 12th, 2009
- Added Set Default Timezone functionality (PHP 5.1+ ONLY)

Version 1.3 -January 9th, 2009
- Cleaned up code
- Added more comments for easier installation instructions
